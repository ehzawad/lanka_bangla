// peer connection
var pc = null;
var dc = null, dcInterval = null;
var audio1 = "nn";
var stopper_cnt = 0

//alert(1);

// start_btn = document.getElementById('start');
// stop_btn = document.getElementById('stop');
// statusField = document.getElementById('status');
const microphoneIcon = document.getElementById("sendButton");
const userInput = document.getElementById("userInput");
// const paperplaneIcon = document.getElementById("sendButton");

var mic_toggle = 0

userInput.addEventListener("input", function() {
    if (userInput.value.trim() === "") {
        microphoneIcon.innerHTML = '<i class="fa fa-paper-plane" aria-hidden="true"></i>';
        mic_toggle = 0
    } else {
        microphoneIcon.innerHTML = '<i class="fa fa-paper-plane" aria-hidden="true"></i>';
        mic_toggle = 2
    }
});

// Add an event listener to the textarea for Enter key press
userInput.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        // Reset the microphone icon to active mode
        microphoneIcon.innerHTML = '<i class="fa fa-paper-plane" aria-hidden="true"></i>';
        mic_toggle = 1
    }
});

function generateUUID() { // Public Domain/MIT
    var d = new Date().getTime();//Timestamp
    var d2 = ((typeof performance !== 'undefined') && performance.now && (performance.now()*1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16;//random number between 0 and 16
        if(d > 0){//Use timestamp until depleted
            r = (d + r)%16 | 0;
            d = Math.floor(d/16);
        } else {//Use microseconds since page-load if supported
            r = (d2 + r)%16 | 0;
            d2 = Math.floor(d2/16);
        }
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

var sender=generateUUID();
function send_message(){
    //alert("returning...");
    return;
    var userInput=$("#userInput").val();
    
    //alert("client send_message")
    console.log(userInput);

    if(userInput.length<=0){
        return;
    }
    var xhr = new XMLHttpRequest();
	// http://172.21.112.11:5025
    x = xhr.open('GET', 'https://smartservice.lankabangla.com/chatbot/message?sender='+sender+'&output=' + encodeURIComponent(userInput), true);

    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
        var data = JSON.parse(xhr.responseText);

        $("#userInput").val("");
      }
    };

    xhr.onerror = function () {
    // Handle the error case
    console.error('An error occurred while making the request.');
    };

    xhr.send(null);
}

function btn_show_stop() {
    microphoneIcon.innerHTML = '<i class="fa fa-paper-plane-slash" aria-hidden="true"></i>'
}

function btn_show_start() {
    microphoneIcon.innerHTML = '<i class="fa fa-paper-plane" aria-hidden="true"></i>'
}

microphoneIcon.addEventListener("click", function() {
    send_message();

        
});
