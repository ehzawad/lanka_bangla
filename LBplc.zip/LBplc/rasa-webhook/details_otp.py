import requests
import json
import random
import time
from datetime import datetime

def generate_otp() -> str:
    return ''.join([str(random.randint(0, 9)) for _ in range(6)])

def test_otp_server():
    test_otp = generate_otp()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n=== OTP SERVER TEST [{timestamp}] ===")
    print(f"Generated OTP: {test_otp}")
    
    url = 'http://192.168.214.65/ccmw/notification/common-api-sms-function'
    test_params = {
        'sercret': 'PVFzWnlWQmJsdkNxQUszcWJrbFlUNjJVREpVMXR6R09kTHN5QXNHYSt1ZWM=',
        'rm': 'I',
        'callid': 124534654,
        'connname': 'MWGCLSMS',
        'cli': '01811481899',
        'sid': 'LBFPLC',
        'ncode': 'SNDOTP',
        'sivrlnk': test_otp,
        'csms_id': f'4473433434pZ{test_otp}'
    }
    
    print("\n=== REQUEST DETAILS ===")
    print(f"URL: {url}")
    print("Parameters:")
    for key, value in test_params.items():
        print(f"  {key}: {value}")
    
    print("\n=== SENDING REQUEST ===")
    start_time = time.time()
    
    try:
        response = requests.get(url, params=test_params, timeout=10)
        elapsed_time = time.time() - start_time
        
        print("\n=== RESPONSE DETAILS ===")
        print(f"Status code: {response.status_code}")
        print(f"Response time: {elapsed_time:.3f} seconds")
        print(f"Response headers:")
        for header, value in response.headers.items():
            print(f"  {header}: {value}")
        
        print("\nRaw response text:")
        print(response.text)
        
        try:
            data = response.json()
            print("\n=== PARSED JSON RESPONSE ===")
            print(json.dumps(data, indent=2))
            
            if data and isinstance(data, list) and len(data) > 0:
                result = data[0]
                print("\n=== RESULT ANALYSIS ===")
                print(f"Status: {result.get('gstatus')}")
                print(f"Message: {result.get('gmmsg')}")
                
                if 'responseData' in result:
                    print("\nResponse data:")
                    print(json.dumps(result['responseData'], indent=2))
                
                if result.get('gstatus') is True:
                    print(f"\n✅ SUCCESS: OTP {test_otp} was sent successfully to {test_params['cli']}!")
                else:
                    print(f"\n❌ FAILURE: OTP {test_otp} failed to send to {test_params['cli']}!")
            else:
                print("\n⚠️ UNEXPECTED RESPONSE FORMAT")
        except json.JSONDecodeError as je:
            print("\n=== JSON PARSING ERROR ===")
            print(f"Error: {str(je)}")
            print("Response couldn't be parsed as JSON")
    except requests.exceptions.Timeout as te:
        print("\n=== TIMEOUT ERROR ===")
        print(f"Request timed out after {te.args[0]} seconds")
    except requests.exceptions.ConnectionError as ce:
        print("\n=== CONNECTION ERROR ===")
        print(f"Failed to connect to server: {str(ce)}")
    except Exception as e:
        print("\n=== UNEXPECTED ERROR ===")
        print(f"Type: {type(e).__name__}")
        print(f"Message: {str(e)}")
        print(f"Args: {e.args}")
    
    print("\n=== TEST COMPLETE ===")
    return True

if __name__ == "__main__":
    test_otp_server()
