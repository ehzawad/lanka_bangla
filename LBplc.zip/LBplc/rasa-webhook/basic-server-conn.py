import socket
import requests

def test_server_connection():
    try:
        # Test basic socket connection
        sock = socket.create_connection(("192.168.11.105", 443), timeout=5)
        sock.close()
        print("Socket connection successful")
        
        # Test HTTPS connection
        response = requests.get("https://192.168.11.105", verify=False, timeout=5)
        print(f"HTTPS connection successful: {response.status_code}")
        
    except socket.error as e:
        print(f"Socket connection failed: {e}")
    except requests.exceptions.RequestException as e:
        print(f"HTTPS connection failed: {e}")

test_server_connection()                    

