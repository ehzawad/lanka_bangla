import requests
import json
import random

def generate_otp() -> str:
    """Generate a random 6-digit OTP"""
    return ''.join([str(random.randint(0, 9)) for _ in range(6)])

def test_otp_server():
    # Generate a random 6-digit OTP
    test_otp = generate_otp()
    print(f"Generated OTP for testing: {test_otp}")
    
    url = 'http://192.168.214.65/ccmw/notification/common-api-sms-function'
    test_params = {
        'sercret': 'PVFzWnlWQmJsdkNxQUszcWJrbFlUNjJVREpVMXR6R09kTHN5QXNHYSt1ZWM=',
        'rm': 'I',
        'callid': 124534654,  # Using numeric value as required
        'connname': 'MWGCLSMS',
        'cli': '01811481899',  # Using the specified test number
        'sid': 'LBFPLC',
        'ncode': 'SNDOTP',
        'sivrlnk': test_otp,  # Using the generated OTP
        'csms_id': f'4473433434pZ{test_otp}'  # Including OTP in csms_id
    }
    
    print("Testing OTP server connectivity...")
    print(f"Sending OTP {test_otp} to phone number {test_params['cli']}")
    
    try:
        response = requests.get(url, params=test_params, timeout=10)
        print(f"Status code: {response.status_code}")
        print(f"Response: {response.text}")
        
        # Parse and analyze the response
        try:
            data = response.json()
            if data and isinstance(data, list) and len(data) > 0:
                result = data[0]
                print(f"Result status: {result.get('gstatus')}")
                print(f"Result message: {result.get('gmmsg')}")
                
                if 'responseData' in result and isinstance(result['responseData'], dict):
                    # Check for validation errors
                    print("Validation errors:", result['responseData'])
                elif result.get('gstatus') is True:
                    print(f"SUCCESS: OTP {test_otp} was sent successfully!")
                else:
                    print("Response data:", result)
            else:
                print("Unexpected response format")
        except json.JSONDecodeError:
            print("Could not parse JSON response")
            
        return True
    except Exception as e:
        print(f"Connection error: {type(e).__name__}: {str(e)}")
        return False

if __name__ == "__main__":
    test_otp_server()
