from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker, FormValidationAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import FollowupAction
from rasa_sdk.events import SlotSet
from typing import Dict, Text, List
# At the top of actions.py
from rasa_sdk.events import AllSlotsReset, Form, SlotSet, EventType
from rasa_sdk import Tracker
from rasa_sdk.events import EventType, UserUtteranceReverted, ActionReverted, UserUttered, ActionExecuted
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk import Action
from rasa_sdk.types import DomainDict
import requests
import random
import time
import pprint
import json
import urllib3
from urllib3.exceptions import MaxRetryError, NewConnectionError
from rasa_sdk.events import ActiveLoop
from urllib3.util.retry import Retry 
from requests.adapters import HTTPAdapter


# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

goBackTrack = {}

userListDict = {}


class ActionCustomFallback(Action):
    def name(self) -> Text:
        return "action_custom_fallback"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        print("action_custom_fallback")

        gobk = [{"title": "Go Back", "payload": "/go_back"}]
        #if(last_intent=='nlu_fallback'):
        print("*********************  Inside fallback  **********************************")
        dispatcher.utter_message(text="You are really testing my abilities now. Surely, I will be working on this. You can ask me questions directly using keywords such as Account Information, Outstanding, Products, Discounts, Payments, Fees & Charges, BEFTN, Chequebook, Branch Locations etc.", buttons = gobk )
        return []

# action_service_type_credit_card
class ActionServiceType(Action):
    def name(self) -> Text:
        return "action_service_type_credit_card"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("action_service_type_credit_card")
        print(tracker.latest_message)
        last_intent = tracker.latest_message["intent"]["name"]
        # last_text = tracker.latest_message["text"]
        service_type = tracker.get_slot("service_type")
        if service_type is None:
            service_type = "credit_card"
            return [SlotSet("service_type", service_type)]
        else:
            return []


class ActionServiceTypeMasterCard(Action):
    def name(self) -> Text:
        return "action_service_type_master_card"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("action_service_type_master_card")
        print(tracker.latest_message)
        last_intent = tracker.latest_message["intent"]["name"]
        # last_text = tracker.latest_message["text"]
        service_type = tracker.get_slot("service_type")
        if service_type is None:
            service_type = "master_card"
            return [SlotSet("service_type", service_type)]
        else:
            return []
        

class ActionServiceTypeVisaCard(Action):
    def name(self) -> Text:
        return "action_service_type_visa_card"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("action_service_type_visa_card")
        print(tracker.latest_message)
        last_intent = tracker.latest_message["intent"]["name"]
        # last_text = tracker.latest_message["text"]
        service_type = tracker.get_slot("service_type")
        if service_type is None:
            service_type = "visa_card"
            return [SlotSet("service_type", service_type)]
        else:
            return []

        
# action_service_type_deposit
class ActionServiceTypeDeposit(Action):
    def name(self) -> Text:
        return "action_service_type_deposit"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # if service_type is None, then set it to credit_card
        print("action_service_type_deposit")
        service_type = tracker.get_slot("service_type")
        if service_type is None:
            service_type = "deposit"
            return [SlotSet("service_type", service_type)]
        else:
            return []
        
# action_service_type_loan
class ActionServiceTypeLoan(Action):
    def name(self) -> Text:
        return "action_service_type_loan"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # if service_type is None, then set it to credit_card
        print("action_service_type_loan")
        service_type = tracker.get_slot("service_type")
        if service_type is None:
            service_type = "loan"
            return [SlotSet("service_type", service_type)]
        else:
            return []


class BankAPI:
    def __init__(self):
        self.headers = {"Content-Type": "application/json"}
        self.base_url = 'http://192.168.214.65/ccmw'
        self.base_url_data = 'http://192.168.214.12/ccmw'
        self.secret = 'PVFzWnlWQmJsdkNxQUszcWJrbFlUNjJVREpVMXR6R09kTHN5QXNHYSt1ZWM='
        self.otp_store = {}
        self.otp_validity = 300  # 5 minutes

    def generate_otp(self) -> str:
        return ''.join([str(random.randint(0, 9)) for _ in range(6)])

    def store_otp(self, phone_number: str, otp: str):
        expiration_time = time.time() + self.otp_validity
        self.otp_store[phone_number] = {'otp': otp, 'expiration': expiration_time}

    def verify_otp(self, phone_number: str, user_input: str) -> bool:
        if phone_number not in self.otp_store:
            return False
        stored_data = self.otp_store[phone_number]
        if time.time() > stored_data['expiration']:
            del self.otp_store[phone_number]
            return False
        if user_input == stored_data['otp']:
            del self.otp_store[phone_number]
            return True
        return False

    def send_otp(self, phone_number: str) -> Dict[str, Any]:
        otp = self.generate_otp()
        print(f"Generated OTP: {otp}")
        self.store_otp(phone_number, otp)
        url = f'{self.base_url}/notification/common-api-sms-function'
        
        ####################DEBUG PURPOSE####################
       # if phone_number == "01811481899":
        #    print("DEBUGGINGG")
         #   phone_number = "01715836598"
        #######################################
        
        params = {
            'sercret': self.secret,
            'rm': 'I',
            'callid': '124534654',
            'connname': 'MWGCLSMS',
            'cli': phone_number,
            'sid': 'LBFPLC',
            'ncode': 'SNDOTP', # SNDOTP
            'sivrlnk': otp,
            'csms_id': f'4473433434pZ{otp}'
        }
        try:
            response = requests.get(url, params=params)
            data = response.json()
            print(data)
            #f = open('/usr/local/LBplc/rasa-webhook/otp.log')
            #f.write(str(data)+'\n')
            #f.close()
            if data and isinstance(data, list) and len(data) > 0:
                result = data[0]
                if result.get('status') == 'SUCCESS':
                    return {'success': True, 'message': 'OTP sent successfully'}
                    print("OTP sent successfully")
                else:
                    return {'success': False, 'message': 'Failed to send OTP'}
                    print("Failed to send OTP")
            else:
                return {'success': False, 'message': 'Invalid response from SMS API'}
                print("Invalid response from SMS API")
        except requests.exceptions.RequestException as e:
            #return {'success': False, 'message': f"Error sending OTP: {str(e)}"}
            return {'success': False, 'message': 'Failed to send OTP'}
            print("Error sending OTP: {str(e)}")
        

    def fetch_api_data(self, cli: str, terid: str) -> Dict[str, Any]:
        url = f'{self.base_url_data}/card/common-api-function'
        params = {
            'sercret': self.secret,
            'rm': 'I',
            'callid': '12324243433',
            'connname': 'MWGCAAMB',
            'cli': cli,
            'terid': terid
        }
        try:
            response = requests.get(url, params=params)
            # pprint.pprint(response)
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error fetching API data: {str(e)}")
            return None


    def process_api_data(self, data: List[Dict[str, Any]], category: str) -> List[Dict[str, Any]]:
        if not data or not isinstance(data[0], dict):
            print(f"Invalid data format for {category}")
            return []
        
        response_data = data[0].get('responseData', [])
        print("API RESPONSE - Start", "*"*50)
        pprint.pprint(response_data)
        print("API RESPONSE - End", "*"*50)
        
        if not response_data:
            print(f"No response data available for {category}")
            return []

        processed_data = [
            {
                'CardNumber': account.get('CardNumber', ''),
                'Name': account.get('Name', ''),
                'CreditBalance': account.get('CreditBalance', ''),
                'MinimumPay': account.get('MinimumPay', ''),
                'CreditLimit': account.get('CreditLimit', ''),
                
                'PRODUCT_NM': account.get('PRODUCT_NM', ''),
                'ACCOUNTNUMBER': account.get('ACCOUNTNUMBER', ''),
                'ACCOUNTTITLE': account.get('ACCOUNTTITLE', ''),
                'ACCOUNT_STATUS': account.get('ACCOUNT_STATUS', ''),
                'TERM': account.get('TERM', ''),
                'INTEREST_RATE': account.get('INTEREST_RATE', ''),
                'OPEN_DATE': account.get('OPEN_DATE', ''),
                'RENEWAL_DATE': account.get('RENEWAL_DATE', ''),
                'ACCOUNTMATURITYDATE': account.get('ACCOUNTMATURITYDATE', ''),
                'INSTALLMENTAMOUNT': account.get('INSTALLMENTAMOUNT', ''),
                'CURRENT_BALANCE': account.get('CURRENT_BALANCE', ''),
                'MATURITY_BALANCE': account.get('MATURITY_BALANCE', ''),
                
                'ACC_STATUS': account.get('ACC_STATUS', ''),
                'LOAN_AMOUNT': account.get('LOAN_AMOUNT', ''),
                'INT_RATE': account.get('INT_RATE', ''),
                'EMI_PAID': account.get('EMI_PAID', ''),
                'EMI_AMOUNT': account.get('EMI_AMOUNT', ''),
                'NEXTINSTDATE': account.get('NEXTINSTDATE', ''),
                'CURRENTOUTSTANDING': account.get('CURRENTOUTSTANDING', ''),
                'START_DATE': account.get('START_DATE', ''),
                'EXPIRY_DT': account.get('EXPIRY_DT', ''),
            } for account in response_data
        ]
        
        return processed_data

    def get_account_data(self, cli: str, categories: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        result = {}
        for category in categories:
            data = self.fetch_api_data(cli, category)
            if data:
                processed_data = self.process_api_data(data, category)
                result[category] = processed_data
            else:
                print(f"Failed to fetch data for {category}")
        return result

    def get_master_data(self, cli: str) -> List[Dict[str, Any]]:
        data = self.fetch_api_data(cli, 'Master')
        return self.process_api_data(data, 'Master')

    def get_visa_data(self, cli: str) -> List[Dict[str, Any]]:
        data = self.fetch_api_data(cli, 'VISA')
        return self.process_api_data(data, 'VISA')

    def get_debit_data(self, cli: str) -> List[Dict[str, Any]]:
        data = self.fetch_api_data(cli, 'Debit')
        return self.process_api_data(data, 'Debit')

    def get_loan_data(self, cli: str) -> List[Dict[str, Any]]:
        data = self.fetch_api_data(cli, 'Loan')
        return self.process_api_data(data, 'Loan')


# Initialize BankAPI
bank_api = BankAPI()


def clean_name(name):
    return name

class ActionServiceTypeCommon(Action):
    def name(self) -> Text:
        return "action_service_type_common"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("action_service_type_common")
        #return [SlotSet(slot_name, None) for slot_name in ["otp_sender_sms", "otp", "otp_verified", "service_type"]]
        
        print(tracker.latest_message)

        last_intent = tracker.latest_message["intent"]["name"]
        service_type = tracker.get_slot("service_type")
        print(last_intent)

        current_intent_name = tracker.latest_message['intent']['name']
        print(f"zawad {current_intent_name}")

        rename = ''
        if current_intent_name == "loan_sms":
            rename = "Loan Service"
        elif current_intent_name == "deposit_sms":
            rename = "Deposit Scheme"
        else:
            rename = "Credit Card"

        if service_type is None:
            if last_intent == "master_card_sms":
                service_type = "master_card"

            elif last_intent == "visa_card_sms":
                service_type = "visa_card"
                
            elif last_intent == "credit_card_sms":
                service_type = "credit_card"
                
            elif last_intent == "deposit_sms":
                service_type = "deposit"

            elif last_intent == "loan_sms":
                service_type = "loan"


            dispatcher.utter_message(text=f"Thank you for using LankaBangla {rename} Surely, I can help you.")
            dispatcher.utter_message(text="Please give your mobile number for sending you an OTP?")
            return [SlotSet("service_type", service_type)]
        else:
            return []



# zawad
class ActionResetOtpFormSlots(Action):
    def name(self) -> Text:
        return "action_reset_otp_form_slots"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        print("action_reset_otp_form_slots")
        print(tracker.slots)
        # Clear the userListDict entry for this user if needed
        # if tracker.sender_id in userListDict:
        #     userListDict[tracker.sender_id] = {}  # Clear but keep the dict entry
            
        return [
            SlotSet("otp_sender_sms", None),
            SlotSet("otp", None),
            SlotSet("otp_verified", None),
            SlotSet("service_type", None),
            ActiveLoop(None),  # Explicitly deactivate any active form
            SlotSet("requested_slot", None)  # Explicitly clear requested slot
        ]
from rasa_sdk.events import SlotSet

###############################################  
class ValidateOTPSmsForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_otp_sms_form"

    def __init__(self):
        self._validating_otp_sender_sms = False  # Prevent duplicate OTP sender validation
        self._validating_otp = False  # Prevent duplicate OTP validation

    async def required_slots(
        self,
        domain_slots: List[Text],
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> List[Text]:
        return ["otp_sender_sms", "otp"]



    #def validate_otp_sender_sms(
    def validate_otp_sender_sms(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """Validate `otp_sender_sms` value and send OTP."""
        name = clean_name(slot_value)
        print("Validating otp_sender_sms")
        
        print("phone Number: ", name)
        print("intent name: ", end=" ")
        currentIntent = tracker.get_intent_of_latest_message()

        print(tracker.latest_message['intent']['name'])
        
        current_intent_name = tracker.latest_message['intent']['name']
        print(f"zawad {current_intent_name}")

        formList = ["master_card_sms", "visa_card_sms", "credit_card_sms", "deposit_sms", "loan_sms"]
        service_type = tracker.get_slot("service_type")
        
        rename = ''
        if current_intent_name == "loan_sms":
            rename = "Loan Service"
        elif current_intent_name == "deposit_sms":
            rename = "Deposit Scheme"
        else:
            rename = "Credit Card"


        print(f"rename {rename}")

        # if currentIntent != "inform":
        #     if currentIntent in formList:

        #         # dispatcher.utter_message(text="Alright No Problem, Please provide me your number so that I can send you an OTP.")

        #         dispatcher.utter_message(text=f"Thank you for using LankaBangla {rename} Surely, I can help you.")
        #         dispatcher.utter_message(text="Please give your mobile number for sending you an OTP?")

        #         if currentIntent == "master_card_sms":
        #             service_type = "master_card"
                    
        #         elif currentIntent == "visa_card_sms":
        #             service_type = "visa_card"
                    
        #         elif currentIntent == "credit_card_sms":
        #             service_type = "credit_card"
                    
        #         elif currentIntent == "deposit_sms":
        #             service_type = "deposit"
                    
        #         elif currentIntent == "loan_sms":
        #             service_type = "loan"
                
        #         return {"otp_sender_sms": None, "service_type": service_type, "requested_slot": "otp_sender_sms"}
                
        #     else:
        #         AA = Action_Otions1()
        #         AA.run(dispatcher, tracker, domain)
        #         return {"requested_slot": None}
        
        print(f"this is after the service type")

        if not name.isdigit() or len(name) != 11:
            dispatcher.utter_message(text="The number should be a valid BD number, and it has to be 11 digits long.")
            return {"otp_sender_sms": None}

        # Send OTP
        try:
            result = bank_api.send_otp(name)
            f = open('/usr/local/LBplc/rasa-webhook/otp.log','a')
            f.write(str(result))
            f.close()
        except e:
            f = open('/usr/local/LBplc/rasa-webhook/otp.log','a')
            f.write(str(e))
            f.close()
        if result['success']:
            print("RRRRRRRRRRRRRRRRRRR")
            print(tracker.latest_message.get("text"))
            dispatcher.utter_message(text="OTP sent successfully. Please check your phone and enter the OTP.")
            # if tracker.sender_id not in userListDict:
            #     userListDict[tracker.sender_id] = {"phoneNumber": name, "serviceType": service_type}
            # else:
            #     userListDict[tracker.sender_id] = {"phoneNumber": name, "serviceType": service_type}
                
            # return {"otp_sender_sms": name}
            # by rukon # return {"otp_sender_sms": name, "otp": None, "requested_slot": "otp"}
            return {"otp_sender_sms": name, "requested_slot": "otp"}
        else:
            print("FFFFFFFF")
            dispatcher.utter_message(text=f"Failed to send OTP")
            return {"otp_sender_sms": None}


        

        # dispatcher.utter_message(text="OTP has been sent to your phone. Please enter the OTP to proceed.")
        # self._validating_otp_sender_sms = False
        # return {"otp_sender_sms": phone_number, "requested_slot": "otp"}


    def validate_otp(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """Validate `otp` value, verify OTP, and fetch account data."""
        if tracker.active_loop.get("name") != "otp_sms_form":
            print("No form or a different form is active.")
            return {"otp": None}

        if self._validating_otp:
            print("OTP validation already in progress, skipping duplicate call.")
            return {"otp": None}

        self._validating_otp = True
        slot_values = tracker.current_slot_values()
        print(f"jan 15..................{slot_values}")
        user_input = tracker.latest_message.get("text", "").strip()
        phone_number = slot_values.get("otp_sender_sms", None)
        print("hello man")
        print(type(phone_number))
        print(type(tracker.get_slot("otp_sender_sms")))

        # If this is a prefilled value (matches phone number)

        # Now process the actual input
        otp = user_input  # Use user_input instead of slot_value

        # Validate OTP input
        if len(otp) != 6:
            dispatcher.utter_message(text="The OTP must be a 6-digit number. Please try again.")
            self._validating_otp = False
            return {"otp": None}

        # Verify 
        if bank_api.verify_otp(phone_number, otp):
            dispatcher.utter_message(text="OTP verified successfully.")
            service_type = slot_values.get("service_type")

            # Fetch and display account data
            account_data = bank_api.get_account_data(phone_number, ['Master', 'VISA', 'Deposit', 'Loan'])
            
            if service_type == "credit_card":
                self.display_credit_card_data(dispatcher, account_data.get('Master', []), account_data.get('VISA', []))
            elif service_type == "master_card":
                self.display_master_card_data(dispatcher, account_data.get('Master', []))
            elif service_type == "visa_card":
                self.display_visa_card_data(dispatcher, account_data.get('VISA', []))
            elif service_type == "deposit":
                self.display_deposit_data(dispatcher, account_data.get('Deposit', []))
            elif service_type == "loan":
                self.display_loan_data(dispatcher, account_data.get('Loan', []))
            else:
                dispatcher.utter_message(text="No data found for the selected service type.")
                dispatcher.utter_message(response="utter_no_data_found")

            self._validating_otp = False
            return {"otp": otp, "otp_verified": True, "requested_slot": None}

        # Handle invalid OTP
        dispatcher.utter_message(text="Invalid OTP. Please try again.")
        self._validating_otp = False
        return {"otp": None}

########################

    def display_deposit_data(self, dispatcher: CollectingDispatcher, deposit_data):
        #print("*"*50)
        print("DepositData")
        #pprint.pprint(deposit_data)
        #print("*"*50)
        #dispatcher.utter_message(text="HELO FROM DEPOSIT")
        #return []
        if deposit_data:
            # dispatcher.utter_message(text=f"Deposit Account Information:")
            ttt = ""
            aa = ""
            for cc, account in enumerate(deposit_data):
                #print(account)
                if cc == 0:
                    ttt = f'Deposit Account Information: <table id="g-table"> <thead> <tr> <td colspan="2" center>Deposit {cc+1}</td> </tr> </thead> <tr> <td>Product</td> <td>{account["PRODUCT_NM"]}</td> </tr> <tr> <td>Account No</td> <td>{account["ACCOUNTNUMBER"]}</td> </tr> <tr> <td>Name</td> <td>{account["ACCOUNTTITLE"]}</td> </tr> <tr> <td>Status</td> <td>{account["ACCOUNT_STATUS"]}</td> </tr> <tr> <td>Term in Month</td> <td>{account["TERM"]}</td> </tr> <tr> <td>Interest Rate</td> <td>{account["INTEREST_RATE"]}</td> </tr> <tr> <td>A/C Opening Date</td> <td>{account["OPEN_DATE"]}</td> </tr> <tr> <td>Renewal Date</td> <td>{account["RENEWAL_DATE"]}</td> </tr> <tr> <td>Maturity Date</td> <td>{account["ACCOUNTMATURITYDATE"]}</td> </tr> <tr> <td>Deposited/Installment Amount BDT</td> <td>{account["INSTALLMENTAMOUNT"]}</td> </tr> <tr> <td>Current Amount BDT</td> <td>{account["CURRENT_BALANCE"]}</td> </tr> <tr> <td>Maturity Amount BDT</td> <td>{account["MATURITY_BALANCE"]}</td> </tr></table>'
                    aa+=ttt+' '
                else:
                    ttt = f'<table id="g-table"> <thead> <tr> <td colspan="2" center>Deposit {cc+1}</td> </tr> </thead> <tr> <td>Product</td> <td>{account["PRODUCT_NM"]}</td> </tr> <tr> <td>Account No</td> <td>{account["ACCOUNTNUMBER"]}</td> </tr> <tr> <td>Name</td> <td>{account["ACCOUNTTITLE"]}</td> </tr> <tr> <td>Status</td> <td>{account["ACCOUNT_STATUS"]}</td> </tr> <tr> <td>Term in Month</td> <td>{account["TERM"]}</td> </tr> <tr> <td>Interest Rate</td> <td>{account["INTEREST_RATE"]}</td> </tr> <tr> <td>A/C Opening Date</td> <td>{account["OPEN_DATE"]}</td> </tr> <tr> <td>Renewal Date</td> <td>{account["RENEWAL_DATE"]}</td> </tr> <tr> <td>Maturity Date</td> <td>{account["ACCOUNTMATURITYDATE"]}</td> </tr> <tr> <td>Deposited/Installment Amount BDT</td> <td>{account["INSTALLMENTAMOUNT"]}</td> </tr> <tr> <td>Current Amount BDT</td> <td>{account["CURRENT_BALANCE"]}</td> </tr> <tr> <td>Maturity Amount BDT</td> <td>{account["MATURITY_BALANCE"]}</td> </tr></table>'
                    aa+=ttt+' '
                    
                #dispatcher.utter_message(text=ttt)
            print("R"*100)
            print(aa)
            print("R"*100)
            dispatcher.utter_message(text=aa)
            
        else:
            dispatcher.utter_message(text="No deposit account information found for your account.")
            dispatcher.utter_message(response="utter_no_data_found")

    def display_loan_data(self, dispatcher: CollectingDispatcher, loan_data):
        if loan_data:
            # dispatcher.utter_message(text="Loan Account Information:")
            print("*"*50)
            print("LoanData")
            pprint.pprint(loan_data)
            print("*"*50)
            for cc, account in enumerate(loan_data):
                if cc == 0:
                    ttt = f'Loan Account Information:<table id="g-table"> <thead> <tr> <td colspan="2" center>Loan {cc+1}</td> </tr> </thead> <tr> <td>Product</td> <td>{account["PRODUCT_NM"]}</td> </tr> <tr> <td>Account No</td> <td>{account["ACCOUNTNUMBER"]}</td> </tr> <tr> <td>Name</td> <td>{account["ACCOUNTTITLE"]}</td> </tr> <tr> <td>Status</td> <td>{account["ACC_STATUS"]}</td> </tr> <tr> <td>Loan Amount BDT</td> <td>{account["LOAN_AMOUNT"]}</td> </tr> <tr> <td>Interest Rate</td> <td>{account["INT_RATE"]}</td> </tr> <tr> <td>No of EMI Paid</td> <td>{account["EMI_PAID"]}</td> </tr> <tr> <td>EMI Amount BDT</td> <td>{account["EMI_AMOUNT"]}</td> </tr> <tr> <td>Next Installment Date</td> <td>{account["NEXTINSTDATE"]}</td> </tr> <tr> <td>Outstanding Amount BDT</td> <td>{account["CURRENTOUTSTANDING"]}</td> </tr> <tr> <td>Start Date</td> <td>{account["START_DATE"]}</td> </tr> <tr> <td>Expiry Date</td> <td>{account["EXPIRY_DT"]}</td> </tr></table>'
                else:
                    ttt = f'<table id="g-table"> <thead> <tr> <td colspan="2" center>Loan {cc+1}</td> </tr> </thead> <tr> <td>Product</td> <td>{account["PRODUCT_NM"]}</td> </tr> <tr> <td>Account No</td> <td>{account["ACCOUNTNUMBER"]}</td> </tr> <tr> <td>Name</td> <td>{account["ACCOUNTTITLE"]}</td> </tr> <tr> <td>Status</td> <td>{account["ACC_STATUS"]}</td> </tr> <tr> <td>Loan Amount BDT</td> <td>{account["LOAN_AMOUNT"]}</td> </tr> <tr> <td>Interest Rate</td> <td>{account["INT_RATE"]}</td> </tr> <tr> <td>No of EMI Paid</td> <td>{account["EMI_PAID"]}</td> </tr> <tr> <td>EMI Amount BDT</td> <td>{account["EMI_AMOUNT"]}</td> </tr> <tr> <td>Next Installment Date</td> <td>{account["NEXTINSTDATE"]}</td> </tr> <tr> <td>Outstanding Amount BDT</td> <td>{account["CURRENTOUTSTANDING"]}</td> </tr> <tr> <td>Start Date</td> <td>{account["START_DATE"]}</td> </tr> <tr> <td>Expiry Date</td> <td>{account["EXPIRY_DT"]}</td> </tr></table>'
                    
                dispatcher.utter_message(text=ttt)
                
        else:
            dispatcher.utter_message(text="No loan account information found for your account.")  
            dispatcher.utter_message(response="utter_no_data_found")  

    def display_credit_card_data(self, dispatcher: CollectingDispatcher, master_data, visa_data):
        has_credit_card = False

        # Display Master card data
        if master_data:
            print("*"*50)
            print("Master Data")
            pprint.pprint(master_data)
            print("*"*50)
            has_credit_card = True
            # dispatcher.utter_message(text="Master Card Information:")
            for cc, account in enumerate(master_data):
                if cc == 0:
                    # dispatcher.utter_message(text=f"Due Date: {account['Date']}")
                    ttt = f'Master Card Information:<table id="g-table"> <thead> <tr> <td colspan="2" center>Master Card {cc+1}</td> </tr> </thead> <tr> <td>Card Number</td> <td>{account["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{account["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{account["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{account["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{account["CreditLimit"]}</td> </tr></table>'

                    # dispatcher.utter_message(text=ttt)
                else:
                    ttt = f'<table id="g-table"> <thead> <tr> <td colspan="2" center>Master Card {cc+1}</td> </tr> </thead> <tr> <td>Card Number</td> <td>{account["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{account["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{account["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{account["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{account["CreditLimit"]}</td> </tr></table>'
                    
                dispatcher.utter_message(text=ttt)
        
        # Display Visa card data
        if visa_data:
            print("*"*50)
            print("Visa Data")
            pprint.pprint(visa_data)
            print("*"*50)
            
            has_credit_card = True
            # dispatcher.utter_message(text="Visa Card Information:")
            for cc, account in enumerate(visa_data):
                if cc == 0:
                    # dispatcher.utter_message(text=f"Due Date: {account['Date']}")
                    ttt = f'Visa Card Information:<table id="g-table"> <thead> <tr> <td colspan="2" center>Visa Card {cc+1}</td> </tr> </thead> <tr> <td>Card Number</td> <td>{account["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{account["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{account["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{account["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{account["CreditLimit"]}</td> </tr></table>'

                    dispatcher.utter_message(text=ttt)
                else:
                    ttt = f'<table id="g-table"> <thead> <tr> <td colspan="2" center>Visa Card {cc+1}</td> </tr> </thead> <tr> <td>Card Number</td> <td>{account["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{account["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{account["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{account["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{account["CreditLimit"]}</td> </tr></table>'
                    
                    dispatcher.utter_message(text=ttt)
        
        if not has_credit_card:
            dispatcher.utter_message(text="No credit card information found for your account.")
            dispatcher.utter_message(response="utter_no_data_found")
        else:
            pass
            #dispatcher.utter_message(text="Is there anything else you would like to know about your credit card?")



## new jan 14
    def display_master_card_data(self, dispatcher: CollectingDispatcher, master_data: List[Dict[str, Any]]):
        print("\nDEBUG: Enter display_master_card_data")
        print(f"Master data received: {bool(master_data)}")
        
        if not master_data:
            print("DEBUG: No master card data to display")
            dispatcher.utter_message(text="No master card information found for your account.")
            dispatcher.utter_message(response="utter_no_data_found")
            print("DEBUG: No data messages dispatched")
            return
        
        print("DEBUG: Processing master card data")
        print("*" * 50)
        print("Master Data")
        pprint.pprint(master_data)
        print("*" * 50)
        
        try:
            print("DEBUG: Building first card display")
            ttt = f'Master Card Information:<table id="g-table"> <thead> <tr> <td colspan="2" center>Master Card</td> </tr> </thead> <tr> <td>Card Number</td> <td>{master_data[0]["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{master_data[0]["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{master_data[0]["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{master_data[0]["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{master_data[0]["CreditLimit"]}</td> </tr></table>'
            
            print("DEBUG: Attempting to dispatch message")
            dispatcher.utter_message(text=ttt)
            print("DEBUG: Message dispatched successfully")
            
            print("DEBUG: Attempting to dispatch quick replies")
            dispatcher.utter_message(response='utter_visa_master_card_quick_replies')
            print("DEBUG: Quick replies dispatched")
        except Exception as e:
            print(f"DEBUG: Error in display_master_card_data: {str(e)}")
            dispatcher.utter_message(text="An error occurred while displaying the card information.")
        
        print("DEBUG: Exit display_master_card_data")



    def display_visa_card_data(self, dispatcher: CollectingDispatcher, visa_data):
        has_credit_card = False

        if visa_data:
            print("*"*50)
            print("Visa Data")
            pprint.pprint(visa_data)
            print("*"*50)
            
            has_visa_data = True
            # dispatcher.utter_message(text="Visa Card Information:")
            aa = ""
            for cc, account in enumerate(visa_data):
                if cc == 0:
                    # dispatcher.utter_message(text=f"Due Date: {account['Date']}")
                    ttt = f'Visa Card Information:<table id="g-table"> <thead> <tr> <td colspan="2" center>Visa Card {cc+1}</td> </tr> </thead> <tr> <td>Card Number</td> <td>{account["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{account["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{account["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{account["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{account["CreditLimit"]}</td> </tr></table>'
                    aa+=ttt+" "
                    #dispatcher.utter_message(text=ttt)
                else:
                    ttt = f'<table id="g-table"> <thead> <tr> <td colspan="2" center>Visa Card {cc+1}</td> </tr> </thead> <tr> <td>Card Number</td> <td>{account["CardNumber"]}</td> </tr> <tr> <td>Name</td> <td>{account["Name"]}</td> </tr> <tr> <td>Outstanding BDT</td> <td>{account["CreditBalance"]}</td> </tr> <tr> <td>Minimum Pay BDT</td> <td>{account["MinimumPay"]}</td> </tr> <tr> <td>Credit Limit BDT</td> <td>{account["CreditLimit"]}</td> </tr></table>'
                    aa+=ttt+" "
                #dispatcher.utter_message(text=ttt)
            dispatcher.utter_message(text=aa)
            dispatcher.utter_message(response='utter_visa_master_card_quick_replies')
            
            
        if not visa_data:
            dispatcher.utter_message(text="No visa card information found for your account.")
            dispatcher.utter_message(response="utter_no_data_found")
        else:
            pass
            #dispatcher.utter_message(text="Is there anything else you would like to know about your visa card?")


class Action_Otions1(Action):

    def name(self) -> Text:
        return "action_options1"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # print(str(tracker.current_state()['sender_id']))
        global goBackTrack
        currentSenderID = str(tracker.current_state()['sender_id']) 
        
        
        if currentSenderID not in goBackTrack:
            goBackTrack[currentSenderID] = {"idx": 0, "time": 0, "intentTree": ["greet"]}
            
        
        # last_intent = tracker.get_intent_of_latest_message()
        # print("action_options1: "+last_intent)

        # Get intent from latest message more safely
        last_intent = tracker.latest_message.get("intent", {}).get("name", "no intent")
        print("action_options1:", last_intent)

        if last_intent == "inform" and tracker.slots.get("otp_verified") is True:
            # Skip handling inform intent right after OTP verification
            return []

        previousIntent = list(reversed(tracker.events))
        listIntent = []
        # listremoveIDX = []
        for c,k in enumerate(previousIntent):
            if k["event"] == "user":
                # print(k["parse_data"]["intent"]["name"])
                listIntent.append(k["parse_data"]["intent"]["name"])
                # listremoveIDX.append(c)


        gobk = [{"title": "Go Back", "payload": "/go_back"}]
        if(last_intent=='nlu_fallback'):
            print("*********************  Inside fallback  **********************************")
            dispatcher.utter_message(text="You are really testing my abilities now. Surely, I will be working on this. You can ask me questions directly using keywords such as Account Information, Outstanding, Products, Discounts, Payments, Fees & Charges, BEFTN, Chequebook, Branch Locations etc.", buttons = gobk )
            return []
        
            
        if(last_intent=='go_back'):
            if len(goBackTrack[currentSenderID]["intentTree"]) > 1:
                goBackTrack[currentSenderID]["intentTree"].pop(-1)
            else:
                dispatcher.utter_message(response="utter_atStart")

        else:
            if last_intent != goBackTrack[currentSenderID]["intentTree"][-1]:
                goBackTrack[currentSenderID]["intentTree"].append(last_intent)
            # pass

        
        
        #print("After", "*"*50)
        # print(listIntent)
        #print(goBackTrack)
        #print("*"*50)
        #print(goBackTrack)
        
        last_intent = goBackTrack[currentSenderID]["intentTree"][-1]
        
        if last_intent == "main_node":
            dispatcher.utter_message(response="utter_main_node_text")
            dispatcher.utter_message(response="utter_main_node")

        elif last_intent == "greet":
            dispatcher.utter_message(response="utter_atStart")
        
        elif last_intent == "credit_card_status":
            # print all the slots
            last_text = tracker.latest_message["text"]

            dispatcher.utter_message(response="utter_credit_card_products_text")
            dispatcher.utter_message(response="utter_credit_card_products_buttons")
            dispatcher.utter_message(response="utter_credit_card_products_quick_replies")
            
            
        # deposit_status
        elif last_intent == "deposit_status":
            last_text = tracker.latest_message["text"]

            dispatcher.utter_message(response="utter_deposit_products_buttons")
            dispatcher.utter_message(response="utter_deposit_products_quick_replies")

            
        elif last_intent == "credit_card_email":
            dispatcher.utter_message(text="credit card email")

        elif last_intent == "loan_products":

            custom1 = {
                "payload": "buttonsPayload",
                "data":{
                    "text": "Loan Products, please select",
                    "buttons" : [
                        {"title": "Retail, Personal, Auto, Home Loan", "payload": "/retail", "type": "urlLink", "url": "https://www.lankabangla.com/retail-financial-services/#lankabangla-loan"},
                        
                        {"title": "SME", "type": "urlLink", "url": "https://www.lankabangla.com/sme-financial-services/", "payload": "/SME"},
                        
                        {"title": "Corporate Financial Service", 
                         "type": "urlLink", 
                         "url": "https://www.lankabangla.com/corporate-financial-services/#main", 
                         "payload": "/corporate_financial_service"},
                        
                    ]
                }   
            }
            
            custom2 = {
                "payload": "buttonsPayload",
                "data":{
                    "text": "And",
                    "buttons" : [
                        {"title": "SHIKHA",
                         "payload": "/shikhalink", 
                         "type": "urlLink", 
                         "url": "https://www.lankabangla.com/shikha-loans/"},
                        
                        {"title": "Interest",
                         "payload": "/rateofinterestlink", 
                         "type": "urlLink", 
                         "url": "https://www.lankabangla.com/rate-of-interest/#loan-rate"},
                        
                        {"title": "Apply",
                         "payload": "/apply_for_loan", 
                         "type": ""},
                        
                    ]
                }   
            }
        
            # <a href='https://google.com' target=_blank>Open Link in New Tab</a>
            
            buttons1 = [
                {"title": "Go Back", "payload": "/go_back"},
            ]
                 
            dispatcher.utter_message(custom = custom1)
            dispatcher.utter_message(custom = custom2)
            dispatcher.utter_message(text = "And", buttons = buttons1)
            


        elif last_intent == "credit_card_offers":
            dispatcher.utter_message(response="utter_credit_card_offers_text")
            dispatcher.utter_message(response="utter_credit_card_offers_button_one")
            dispatcher.utter_message(response="utter_credit_card_offers_reward_catalogue_button")
            dispatcher.utter_message(response="utter_credit_card_offers_quick_replies")

        elif last_intent == "deposit_products":

            dispatcher.utter_message(response="utter_deposit_products_buttons")
            dispatcher.utter_message(response="utter_deposit_products_quick_replies")


        
        elif last_intent == "product_information":
            print("intent.....product_information")
            dispatcher.utter_message(response="utter_product_information")

        elif last_intent == "about_us":
            dispatcher.utter_message(response="utter_about_us")

        elif last_intent == "exit":
            dispatcher.utter_message(text="Thank you have a good day!")

        # apply_for_deposit
        elif last_intent == "apply_for_deposit":
            dispatcher.utter_message(response="utter_apply_for_deposit")

        # apply_for_loan
        elif last_intent == "apply_for_loan":
            dispatcher.utter_message(response="utter_apply_for_loan")

        # apply_for_credit_card
        elif last_intent == "apply_for_credit_card":
            dispatcher.utter_message(response="utter_apply_for_credit_card")

        # jan 13 zawad, I exist here
        # elif last_intent == "talk_to_agent":
        #     #dispatcher.utter_message(response="utter_talk_to_agent")

        #     return [
        #         FollowupAction("talk_to_agent_form"),
        #         ActiveLoop("talk_to_agent_form")
        #     ]

        elif last_intent == "existing_customer":
            print("existing_customer intent actions ehzawad")
            # dispatcher.utter_message(response="utter_existing_customer")
            dispatcher.utter_message(response="utter_existing_customer1")
            # dispatcher.utter_message(response="utter_pack_credit_cards")

        elif last_intent == "pack_credit_cards":
            print("pack credit cards")
            dispatcher.utter_message(response="utter_pack_credit_cards")

        elif last_intent == "new_customer":
            print("new Customer")
            custom2 = {
                "payload": "quickReplies",
                "data":[
                    {"title": "Payment Solutions", "payload": "/payment_solutions"},
                    {"title": "Branches", "payload": "/branches"},
                    {"title": "Contact Center", "payload": "/contact_center"},
                    {"title": "Offers", "payload": "/lbfl_offers"},
                    {"title": "Apply Now", "payload": "/apply_now"},
                    {"title": "FinSmart", "payload": "/finsmart", "type": "urlLink", "url": "https://www.lankabangla.com/finsmart/"},
                    {"title": "BEFTN", "payload": "/mastercard_BEFTN"},
                    {"title": "Go Back", "payload": "/go_back"},
                ]   
            }

            custom1 = {
                "payload": "buttonsPayload",
                "data":{
                    "text": "Thank you for your interest in lankabangla, please select",
                    "buttons" : [
                        {"title": "Products", "payload": "/product_information", "type": ""},
                        {"title": "Fee & Charges", "type": "urlLink", "url": "https://www.lankabangla.com/fees-charge/", "payload": "/fee_charges"},
                        {"title": "Rate Of Interest", "type": "urlLink", "url": "https://www.lankabangla.com/rate-of-interest/", "payload": "/fee_charges"},
                    ]
                }   
            }

            dispatcher.utter_message(custom = custom1)
            dispatcher.utter_message(custom = custom2)
            # dispatcher.utter_message(response="utter_new_customer")

        elif last_intent == "deposit":
            dispatcher.utter_message(response="utter_deposit")

        elif last_intent == "loan":
            dispatcher.utter_message(response="utter_loan")

        elif last_intent == "apply_now":
            dispatcher.utter_message(response="utter_apply_now")

        elif last_intent == "shikha":
            print("shikha intent")
            dispatcher.utter_message(text="Shikha is a platform to support and motivate women entrepreneurship through diverse products and services.")
            dispatcher.utter_message(response="utter_shikha")
        
        elif last_intent == "fee_charges":
            print("new fee charges")

            custom2 = {
                "payload": "buttonsPayload",
                "data": {
                    "text": "Thank you for your query. To know about Fees and Charges of LankaBangla products please select from below",
                    "buttons": [
                        {"title": "Credit Card", "type": "urlLink", "url": "https://t.ly/WIuJ", "payload": "/credit_card_info"},
                        {"title": "Shikha Cards", "type": "urlLink", "url": "https://bit.ly/3bb0LRv", "payload": "/shikha_card_info"},
                        {"title": "Retail Financial Service", "type": "urlLink", "url": "https://bit.ly/3dmFoPQ", "payload": "/retail_financial_service_info"},
                    ]
                }
            }


            custom3 = {
                "payload": "buttonsPayload",
                "data": {
                    "text": "and",
                    "buttons": [
                        {"title": "Corporate Financial Services", "type": "urlLink", "url": "https://bit.ly/2N4c71L", "payload": "/corporate_financial_services"},
                        {"title": "SME Financial Services", "type": "urlLink", "url": "https://bit.ly/3rVNvqs", "payload": "/sme_financial_services"},
                        {"title": "Digital Payment Charges", "type": "urlLink", "url": "https://bit.ly/3rVNvqs", "payload": "/digital_payment_charges"},
                    ]
                }
            }

            dispatcher.utter_message(custom = custom2)
            dispatcher.utter_message(custom = custom3)



        elif last_intent == "credit_card_products":
            dispatcher.utter_message(response="utter_credit_card_products_text")
            dispatcher.utter_message(response="utter_credit_card_products_buttons")
            dispatcher.utter_message(response="utter_credit_card_products_quick_replies")

        elif last_intent == "deposit_products":
            dispatcher.utter_message(response="utter_deposit_products")
        
        elif last_intent == "loan_products":
            print("intent loan products")
            dispatcher.utter_message(response="utter_loan_products_button_one")

        elif last_intent == "payment_solutions":
            dispatcher.utter_message(response="utter_payment_solutions")
            dispatcher.utter_message(response="utter_payment_solutions_quick_replies")

        elif last_intent == "branches":
            dispatcher.utter_message(response="utter_branches")

        elif last_intent == "contact_center":
            dispatcher.utter_message(response="utter_contact_center")

        # elif last_intent == "offers":
        #     dispatcher.utter_message(response="utter_offers")

        elif last_intent == "statement":
            dispatcher.utter_message(response="utter_statement_text1")
            # ehzawad
            # dispatcher.utter_message(response="utter_statement_text2")
            dispatcher.utter_message(response="utter_statement_buttons")
            dispatcher.utter_message(response="utter_statement_quick_replies")

        elif last_intent == "service_feedback":
            dispatcher.utter_message(response="utter_service_feedback")

        elif last_intent == "about_lankabangla":
            dispatcher.utter_message(response="utter_about_lankabangla")


        elif last_intent == "visacard_chequebook":
            dispatcher.utter_message(response="utter_visacard_chequebook")
            dispatcher.utter_message(response="utter_visacard_chequebook_quick_replies")

        # utter_mastercard_BEFTN
        elif last_intent == "mastercard_BEFTN":
            dispatcher.utter_message(response="utter_mastercard_BEFTN")
            dispatcher.utter_message(response="utter_mastercard_BEFTN_buttons")
            dispatcher.utter_message(response="utter_mastercard_BEFTN_quick_replies")


        # chequebook
        elif last_intent == "chequebook":
            dispatcher.utter_message(response="utter_chequebook")
            dispatcher.utter_message(response="utter_chequebook_quick_replies")

        # pin_change
        elif last_intent == "pin_change":
            dispatcher.utter_message(response="utter_pin_change")
            dispatcher.utter_message(response="utter_pin_change_text")
            dispatcher.utter_message(response="utter_pin_change_quick_replies")


        # deposit_offers
        elif last_intent == "deposit_offers":
            # dispatcher.utter_message(response="utter_deposit_offers_text")
            dispatcher.utter_message(response="utter_deposit_offers_buttons")
            dispatcher.utter_message(response="utter_deposit_offers_quick_replies")

            
        # lankabangla_management
        elif last_intent == "lankabangla_management":
            print("lankabangla_management intent actions")
            dispatcher.utter_message(response="utter_lankabangla_management")

        # utter_lbfl_offers
        elif last_intent == "lbfl_offers":
            dispatcher.utter_message(response="utter_lbfl_offers")
            dispatcher.utter_message(response="utter_lbfl_offers_quick_replies")

        # no_data_found
        elif last_intent == "no_data_found":
            dispatcher.utter_message(response="utter_no_data_found")
        
        else:
            print("RRRRRRR")
            print(last_intent)
            #otp_sender_sms = tracker.get_slot("otp_sender_sms")
            
            print(f"....tracker {tracker}")

            buttons1 = [
                {"title": "Go Back", "payload": "/go_back"},
            ]
            print("I am inside else, something went wrong")
            dispatcher.utter_message(text="You are really testing my abilities now. Surely, I will be working on this. You can ask me questions directly using keywords such as Account Information, Outstanding, Products, Discounts, Payments, Fees & Charges, BEFTN, Chequebook, Branch Locations etc.", buttons=buttons1)

        return []
        



class ActionGoBack(Action):
    def name(self) -> Text:
        return "action_go_back"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        print("action_go_back")
        AA = Action_Otions1()
        AA.run(dispatcher, tracker, domain)
        return []

################################# jan 13 zawad I exist here...



def clean_name_space(name: str) -> str:
    # Remove spaces and return cleaned name
    return "".join(name.split())

class ActionResetTalkToAgentForm(Action):
    def name(self) -> Text:
        return "action_reset_talk_to_agent_form"

    def run(
        self, 
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any]
    ) -> List:
        """
        This will reset all slots and deactivate the form.
        """
        # return [AllSlotsReset(), Form(None)]

        # - name
        # - phone_number
        return [
            SlotSet("name", None),
            SlotSet("phone_number", None),
            ActiveLoop(None),  # Explicitly deactivate any active form
            SlotSet("requested_slot", None)  # Explicitly clear requested slot
        ]



def clean_name_space(name: str) -> str:
    """Example helper to clean extra spaces or do other name formatting."""
    return " ".join(name.split())

class ActionAskName(Action):
    """
    Custom ask action for 'name' slot.
    If you prefer the built-in `utter_ask_name` response,
    you can skip this and rely on that response in domain.yml.
    """
    def name(self) -> Text:
        return "action_ask_name"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any]
    ) -> List[EventType]:
        dispatcher.utter_message(text="May I have your name, please?")
        return []

class ActionAskPhoneNumber(Action):
    """
    Custom ask action for 'phone_number' slot.
    If you prefer the built-in `utter_ask_phone_number` response,
    you can skip this and rely on that response in domain.yml.
    """
    def name(self) -> Text:
        return "action_ask_phone_number"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any]
    ) -> List[EventType]:
        dispatcher.utter_message(text="Could you provide your phone number?")
        return []

class ValidateTalkToAgentForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_talk_to_agent_form"


    async def required_slots(
        self,
        domain_slots: List[Text],
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> List[Text]:
        return ["name", "phone_number"]


    def validate_name(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> List[EventType]:
        """Validate name value."""
        if not slot_value:
            dispatcher.utter_message(text="Name is required!")
            return {"name": None}
        
        # Clean the name by removing spaces
        cleaned_name = clean_name_space(slot_value)
        print(f"zawad...cleaned_name...{cleaned_name}")
        
        if len(cleaned_name) > 25:
            dispatcher.utter_message(text="Name must not exceed 25 characters!")
            return {"name": None}

        # Valid name "requested_slot": "otp"
        return {"name": cleaned_name, "requested_slot": "phone_number"}

    def validate_phone_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> List[EventType]:
        """Validate phone_number value."""
        if not slot_value:
            dispatcher.utter_message(text="Contact Number is required!")
            return {"phone_number": None}
        
        # Remove any non-digit characters
        cleaned_number = "".join(filter(str.isdigit, str(slot_value)))
        print(f"length...number..{len(cleaned_number)}")
        print(f"cleaned_number....{cleaned_number}")
        if not cleaned_number.isdigit():
            dispatcher.utter_message(text="Contact Number must be numeric!")
            return {"phone_number": None}
            
        if len(cleaned_number) > 11:
            dispatcher.utter_message(text="Contact Number must not exceed 11 digits!")
            return {"phone_number": None}
            
        return {"phone_number": cleaned_number}


class ActionTalkToAgentFormSubmitted(Action):
    def name(self) -> Text:
        return "action_talk_to_agent_form_submitted"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any]
    ) -> List[EventType]:
        
        name = tracker.get_slot("name")
        phone = tracker.get_slot("phone_number")
        
        if not name or not phone:
            # Something was invalid or not set properly
            dispatcher.utter_message(
                text=(
                    "Hello! An agent from LBFL will reply soon. "
                    "You can talk with the agent from 10 AM to 6 PM on weekdays."
                )
            )
            return []

        # If everything is good, do your post-form logic here
        dispatcher.utter_message(
            text=f"Great, {name}! We have your phone number as {phone}."
        )
        
        return []

class ActionTalkToAgentSingleSignIn(Action):
    def name(self) -> Text:
        return "action_talk_to_agent_single_sign_in"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any]
    ) -> List[EventType]:
        """
        Any custom logic to sign the user in or connect them with an agent
        after the form is submitted.
        """
        dispatcher.utter_message(text="We are connecting you to our agent now. Please hold...")
        return []



class ActionTalkToAgentSingleSignIn(Action):
    def name(self) -> Text:
        return "action_talk_to_agent_single_sign_in"

    def create_session_with_retries(self):
        """Create a session with retry strategy"""
        session = requests.Session()
        
        retries = Retry(
            total=3,
            backoff_factor=2,
            status_forcelist=[408, 429, 500, 502, 503, 504],
            allowed_methods=["GET"]
        )
        
        adapter = HTTPAdapter(max_retries=retries)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        name = tracker.get_slot("name")
        phone = tracker.get_slot("phone_number")
        session = None
        
        if(name and phone):
            dispatcher.utter_message(text=f"generate,{name},{phone}")
            return []
        
        print(f"inside action_talk_to_agent_single_sign_in...")
        if not name or not phone:
            dispatcher.utter_message(text="Hello! An agent of LBFL will reply you soon. You can talk with the agent from 10 AM to 6 PM in the weekdays.")
            print(f"Your slots values are {name} {phone}")
            return []

        token_url = f"https://192.168.11.105/robichat/chat_token_gen.php?cname={name}&cnumber={phone}&cverify=Y"
        
        try:
            session = self.create_session_with_retries()
            print("f.created session...{session}")
            response = session.get(token_url, verify=False, timeout=(4, 12))
            response_data = response.json()
            print(f"token_url: {response_data}")
            
            if response_data["result"] != 200:
                dispatcher.utter_message(text="Hello! An agent of LBFL will reply you soon. You can talk with the agent from 10 AM to 6 PM in the weekdays.")
                return []
            
            token = response_data["token"]
            print(f"token ....{token}")
            #chat_base_url = "https://gplxdemo.gplex.net/robichat/chat.php?bGF5b3V0PXJlZCZkb21haW49Z3BseGRlbW8uZ3BsZXgubmV0JnBhZ2VfaWQ9Q0IxMjM0NTY3OSZzaXRlX2tleT1jYmxjOTBkMDk5ODE4YTNjZmI0NTBjNzY2Y2RhYmNiMSZ3d3dfaXA9NTguNjUuMjI4Ljk4JnVzZXI9QUEmdG9rZW49NTVlNzE3NjZmZWI0OGQ5MjFhNzYyZGFlYTU5NzAwMzEmbGFuZ3VhZ2U9RU4mc3ViamVjdD0==="
            final_url = f"{chat_base_url}&api_token={token}"
            
            print(f"final url: {final_url}")
            dispatcher.utter_message(text="I've successfully generated your chat session.")
            dispatcher.utter_message(text="You'll be connected to an agent momentarily.")
            dispatcher.utter_message(text=f"Your chat URL: {final_url}")
            dispatcher.utter_message(text="Note: This chat link will expire in 5 minutes. Please use it soon.")
        
            return []

        except (requests.exceptions.ConnectTimeout, 
                requests.exceptions.ReadTimeout, 
                MaxRetryError, 
                NewConnectionError, 
                requests.exceptions.RequestException,
                json.JSONDecodeError,
                Exception) as e:
            print("I am inside exception")
            dispatcher.utter_message(text="Hello! An agent of LBFL will reply you soon. You can talk with the agent from 10 AM to 6 PM in the weekdays.")
            return []
        finally:
           if session:
               session.close()



# jan 14
from rasa_sdk import Action
from rasa_sdk.events import UserUtteranceReverted
from typing import Any, Text, Dict, List

class ActionRevertInput(Action):
    def name(self) -> Text:
        return "action_revert_input"

    def run(self, dispatcher, tracker, domain) -> List:
        # This action will revert the last user message,
        # as if it never happened
        return [UserUtteranceReverted()]
