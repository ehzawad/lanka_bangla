<?php
// Create a TCP/IP socket
$serverSocket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

// Bind the socket to an address and port
$address = '172.21.112.11';
$port = 443;
socket_bind($serverSocket, $address, $port);

// Listen for incoming connections (max 5 clients in queue)
socket_listen($serverSocket, 5);

echo "Server is listening on $address:$port\n";

while (true) {
    // Accept a connection
    $clientSocket = socket_accept($serverSocket);
    
    if ($clientSocket === false) {
        echo "Socket accept failed: " . socket_strerror(socket_last_error()) . "\n";
        continue;
    }

    // Read data from the client
    $data = socket_read($clientSocket, 1024, PHP_NORMAL_READ);
    
    if ($data) {
        echo "Received: $data\n";
        
        // Send the data back to the client (echo it)
        socket_write($clientSocket, $data, strlen($data));
    }

    // Close the client connection
    socket_close($clientSocket);
}

// Close the server socket
socket_close($serverSocket);
?>
