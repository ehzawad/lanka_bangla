<?php
require 'vendor/autoload.php';
$app = new \Slim\Slim();

// Route to handle chatbot message
//$logFile = __DIR__ . '/app.log';
//function logMessage($message) {
//    global $logFile;
//    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] " . $message . "\n", FILE_APPEND);
//}


function detectDevice() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    
    // Check for iOS devices
    if (strpos($userAgent, 'iPhone') || strpos($userAgent, 'iPad') || strpos($userAgent, 'iPod')) {
        return 'iOS';
    }
    
    // Check for Android devices
    if (strpos($userAgent, 'Android')) {
        return 'Android';
    }
    
    // If neither, assume it's web
    return 'Web';
}


$app->get('/message', function () use ($app) {
    $sender = $app->request()->get('sender');
    //$sender = "58f943f2-19fb-425a-bda7-ef0b5068ddbc";
    $output = $app->request()->get('output');
    //$output = 'hello rokib';
    saveLog($sender.'====>'.$output);
    //logMessage("Received request - Sender: $sender, Output: $output");
    $deviceType = detectDevice();
    saveLog("User is accessing from: " . $deviceType);
 
    if(strlen($sender) > 0){
        $url = "http://192.168.214.12:5054/webhooks/rest/webhook";
        $ch = curl_init($url);
        $payload = json_encode(array("sender" => $sender, "message" => $output));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        
        //$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        //logMessage("Response from webhook - HTTP Status: $httpStatus, Response: $result");
        
        saveLog($result);
        curl_close($ch);
        
        $response = $app->response();
        $response['Content-Type'] = 'application/json';
        $response->body($result);
        $response->headers->set('Access-Control-Allow-Origin', '*'); 
        $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        $response->headers->set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        $response->headers->set('Access-Control-Allow-Credentials', 'true');
        return;
    }
    $app->halt(400, "Invalid request");
});

// Route for the index page
$app->get('/', function () use ($app) {
    $app->render('index.html', array());
});

$app->run();

function saveLog($data){
	$currentDate = date("y-m-d");
        $filename = "/usr/local/apache2/htdocs/chatbot/apilog/{$currentDate}_api.log";
        $file = fopen( $filename, "a+" );
        if( $file == true) {
            fwrite($file, "\n\n".$data );
            fclose($file);
            //die($errData);
        }
}
