<?php
$servername = "192.168.214.12";
$username = "chatbot";
$password = "roott123";
$database = "cc";


function uuid4() {
    /* 32 random HEX + space for 4 hyphens */
    $out = bin2hex(random_bytes(18));

    $out[8]  = "-";
    $out[13] = "-";
    $out[18] = "-";
    $out[23] = "-";

    /* UUID v4 */
    $out[14] = "4";
    
    /* variant 1 - 10xx */
    $out[19] = ["8", "9", "a", "b"][random_int(0, 3)];

    return $out;
}


function getData($servername, $username, $password, $database){
    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully";


    $sql = "SELECT * FROM conversations";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo $row. "<br>";
        }
    } else {
        echo "0 results";
    } 

    // Close the connection
    $conn->close();
}

function insertData($servername, $username, $password, $database, $sender_id,$bot_text,$intent,$confidence,$user_text){
    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $conversation_id = uuid4();
    $phone = '';
    $vendor = '';
    $channel = '';
    $conversation = '';
    $confidence = (string) $confidence;
    $user_text = (string) $user_text;
    
    // Insert query
    $sql = "INSERT INTO conversations (conversation_id, phone,vendor,channel,conversation,bot_id,sender_id,bot_text,intent,confidence,user_text) VALUES ('".$conversation_id."','".$phone."','".$vendor"','".$channel."', '".$conversation."','1','".$sender_id."','".$bot_text."','".$intent."','".$confidence."','".$user_text."')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
}

//getData($servername, $username, $password, $database);

?>
